
// Your React App Code Here
import { useState } from "react";

export default function PetStoreHomePage() {
  const [quizStarted, setQuizStarted] = useState(false);
  const [step, setStep] = useState(1);
  const [answers, setAnswers] = useState({ name: "", breed: "", weight: "", stage: "", goal: "" });
  const [cart, setCart] = useState([]);

  const handleNext = () => setStep(step + 1);
  const handleChange = (field, value) => setAnswers({ ...answers, [field]: value });
  const addToCart = (item) => setCart([...cart, item]);
  const handleCheckout = () => {
    alert("Redirecting to payment... (Stripe integration placeholder)");
  };

  const renderQuiz = () => (
    <div style={{ padding: 20 }}>
      {step === 1 && (
        <div>
          <label>Dog's Name</label>
          <input onChange={(e) => handleChange("name", e.target.value)} />
          <button onClick={handleNext}>Next</button>
        </div>
      )}
      {step === 2 && (
        <div>
          <label>Breed</label>
          <input onChange={(e) => handleChange("breed", e.target.value)} />
          <button onClick={handleNext}>Next</button>
        </div>
      )}
      {step === 3 && (
        <div>
          <label>Weight</label>
          <input onChange={(e) => handleChange("weight", e.target.value)} />
          <button onClick={handleNext}>Next</button>
        </div>
      )}
      {step === 4 && (
        <div>
          <label>Pregnancy Stage</label>
          <select onChange={(e) => handleChange("stage", e.target.value)}>
            <option value="">Select</option>
            <option value="early">Early</option>
            <option value="mid">Mid</option>
            <option value="late">Late</option>
            <option value="postpartum">Postpartum</option>
          </select>
          <button onClick={handleNext}>Next</button>
        </div>
      )}
      {step === 5 && (
        <div>
          <label>Health Goal</label>
          <select onChange={(e) => handleChange("goal", e.target.value)}>
            <option value="">Select</option>
            <option value="energy">Energy</option>
            <option value="gain">Weight Gain</option>
            <option value="recovery">Recovery</option>
          </select>
          <button onClick={() => setStep(6)}>Get Plan</button>
        </div>
      )}
      {step === 6 && (
        <div>
          <h3>Recommended Plan for {answers.name}</h3>
          <ul>
            <li>Pregnancy Support Kit</li>
            <li>High-protein Meal Box</li>
            <li>Hydration & Vitamin Blend</li>
          </ul>
          <button onClick={() => addToCart("Pregnancy Support Kit")}>Shop the Bundle</button>
        </div>
      )}
    </div>
  );

  return (
    <div>
      <h1>MamaPaws</h1>
      <button onClick={() => setQuizStarted(true)}>Start Quiz</button>

      {quizStarted && renderQuiz()}

      <h2>Products</h2>
      <div>
        {["Pregnancy Support Kit", "New Mom Meal Box", "Puppy Growth Bundle"].map((name) => (
          <div key={name}>
            <p>{name}</p>
            <button onClick={() => addToCart(name)}>Add to Cart</button>
          </div>
        ))}
      </div>

      <h2>Cart</h2>
      <ul>
        {cart.map((item, i) => <li key={i}>{item}</li>)}
      </ul>
      {cart.length > 0 && <button onClick={handleCheckout}>Checkout</button>}
    </div>
  );
}
